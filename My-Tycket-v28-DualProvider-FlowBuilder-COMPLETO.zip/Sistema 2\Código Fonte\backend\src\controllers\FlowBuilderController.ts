import { Request, Response } from "express";
import { getRepository } from "typeorm";
import AppError from "../errors/AppError";
import Flow from "../models/Flow";
import FlowExecution from "../models/FlowExecution";
import { FlowEngine } from "../services/FlowEngine/FlowEngine";
import logger from "../utils/logger";
import { WebSocketService } from "../services/WebSocketService";
import { v4 as uuidv4 } from 'uuid';

interface AuthenticatedRequest extends Request {
  user?: {
    id: number;
    companyId: number;
    email: string;
    profile: string;
  };
}

export const index = async (req: AuthenticatedRequest, res: Response): Promise<Response> => {
  try {
    const { companyId } = req.user;
    const {
      page = 1,
      limit = 20,
      search = "",
      category = null,
      isActive = null,
      sortBy = "createdAt",
      sortOrder = "DESC"
    } = req.query;

    const flowRepository = getRepository(Flow);

    const whereConditions: any = { companyId };

    if (search) {
      whereConditions.name = { $ilike: `%${search}%` };
    }

    if (category) {
      whereConditions.category = category;
    }

    if (isActive !== null) {
      whereConditions.isActive = isActive === "true";
    }

    const [flows, count] = await flowRepository.findAndCount({
      where: whereConditions,
      order: { [sortBy as string]: sortOrder as string },
      take: Number(limit),
      skip: (Number(page) - 1) * Number(limit),
      relations: ["createdBy", "updatedBy"],
    });

    return res.status(200).json({
      flows,
      count,
      hasMore: (Number(page) * Number(limit)) < count,
    });
  } catch (err) {
    logger.error("Error listing flows:", err);
    throw new AppError("ERR_LIST_FLOWS", 500);
  }
};

export const show = async (req: AuthenticatedRequest, res: Response): Promise<Response> => {
  try {
    const { id } = req.params;
    const { companyId } = req.user;

    const flowRepository = getRepository(Flow);
    const flow = await flowRepository.findOne({
      where: { id, companyId },
      relations: ["createdBy", "updatedBy", "executions"],
    });

    if (!flow) {
      throw new AppError("ERR_FLOW_NOT_FOUND", 404);
    }

    // Parse JSON fields
    const parsedFlow = {
      ...flow,
      nodes: flow.getNodes(),
      edges: flow.getEdges(),
      variables: flow.getVariables(),
      settings: flow.getSettings(),
      triggerConfig: flow.getTriggerConfig(),
    };

    return res.status(200).json(parsedFlow);
  } catch (err) {
    logger.error("Error showing flow:", err);
    throw new AppError("ERR_SHOW_FLOW", 500);
  }
};

export const store = async (req: AuthenticatedRequest, res: Response): Promise<Response> => {
  try {
    const {
      name,
      description,
      category,
      nodes,
      edges,
      variables = {},
      settings = {},
      triggerType,
      triggerConfig = {},
      tags = [],
      priority = 1,
      timeoutMinutes,
      errorHandling = {},
      analytics = {}
    } = req.body;

    const { id: userId, companyId } = req.user;

    if (!name) {
      throw new AppError("ERR_FLOW_NAME_REQUIRED", 400);
    }

    const flowRepository = getRepository(Flow);

    const flow = flowRepository.create({
      id: uuidv4(),
      name,
      description,
      companyId,
      createdBy: userId,
      category,
      nodes: JSON.stringify(nodes || []),
      edges: JSON.stringify(edges || []),
      variables: JSON.stringify(variables),
      settings: JSON.stringify(settings),
      triggerType,
      triggerConfig: JSON.stringify(triggerConfig),
      tags,
      priority,
      timeoutMinutes,
      errorHandling: JSON.stringify(errorHandling),
      analytics: JSON.stringify(analytics),
      isActive: true,
      isPublished: false,
      version: 1,
    });

    // Emit socket event for real-time updates
    WebSocketService.emitToCompany(companyId, 'flow_created', {
      flow,
      timestamp: new Date(),
    });

    logger.info("Flow created successfully", { flowId: flow.id, name });

    return res.status(201).json(flow);
  } catch (err) {
    logger.error("Error creating flow:", err);
    throw new AppError("ERR_CREATE_FLOW", 500);
  }
};

export const update = async (req: AuthenticatedRequest, res: Response): Promise<Response> => {
  try {
    const { id } = req.params;
    const {
      name,
      description,
      category,
      nodes,
      edges,
      variables = {},
      settings = {},
      triggerType,
      triggerConfig = {},
      tags,
      priority,
      timeoutMinutes,
      errorHandling = {},
      analytics = {},
      isActive
    } = req.body;

    const { id: userId, companyId } = req.user;

    const flowRepository = getRepository(Flow);
    const flow = await flowRepository.findOne({
      where: { id, companyId },
    });

    if (!flow) {
      throw new AppError("ERR_FLOW_NOT_FOUND", 404);
    }

    // Increment version if nodes or edges changed
    const currentVersion = flow.version;
    const newVersion = (nodes || edges) ? currentVersion + 1 : currentVersion;

    const updatedFlow = await flowRepository.update({
      name,
      description,
      category,
      nodes: JSON.stringify(nodes || flow.getNodes()),
      edges: JSON.stringify(edges || flow.getEdges()),
      variables: JSON.stringify(variables || {}),
      settings: JSON.stringify(settings || {}),
      triggerType,
      triggerConfig: JSON.stringify(triggerConfig || {}),
      tags,
      priority,
      timeoutMinutes,
      errorHandling: JSON.stringify(errorHandling || {}),
      analytics: JSON.stringify(analytics || {}),
      isActive: isActive !== undefined ? isActive : flow.isActive,
      version: newVersion,
      updatedBy: userId,
      isPublished: false, // Unpublish when updated
      publishedAt: null,
    });

    // Emit socket event for real-time updates
    WebSocketService.emitToCompany(companyId, 'flow_updated', {
      flow: updatedFlow[0],
      timestamp: new Date(),
    });

    logger.info("Flow updated successfully", { flowId: id, version: newVersion });

    return res.status(200).json(updatedFlow[0]);
  } catch (err) {
    logger.error("Error updating flow:", err);
    throw new AppError("ERR_UPDATE_FLOW", 500);
  }
};

export const remove = async (req: AuthenticatedRequest, res: Response): Promise<Response> => {
  try {
    const { id } = req.params;
    const { companyId } = req.user;

    const flowRepository = getRepository(Flow);
    const flow = await flowRepository.findOne({
      where: { id, companyId },
      relations: ["executions"],
    });

    if (!flow) {
      throw new AppError("ERR_FLOW_NOT_FOUND", 404);
    }

    // Check if flow is being used
    if (flow.isPublished) {
      throw new AppError("ERR_CANNOT_DELETE_PUBLISHED_FLOW", 400);
    }

    if (flow.executions && flow.executions.length > 0) {
      // Soft delete instead of hard delete
      await flowRepository.update({
        isActive: false,
        deletedAt: new Date(),
      });
    } else {
      await flowRepository.remove(flow);
    }

    // Emit socket event
    WebSocketService.emitToCompany(companyId, 'flow_deleted', {
      flowId: id,
      timestamp: new Date(),
    });

    logger.info("Flow deleted successfully", { flowId: id });

    return res.status(204).send();
  } catch (err) {
    logger.error("Error deleting flow:", err);
    throw new AppError("ERR_DELETE_FLOW", 500);
  }
};

export const publish = async (req: AuthenticatedRequest, res: Response): Promise<Response> => {
  try {
    const { id } = req.params;
    const { companyId } = req.user;

    const flowRepository = getRepository(Flow);
    const flow = await flowRepository.findOne({
      where: { id, companyId },
    });

    if (!flow) {
      throw new AppError("ERR_FLOW_NOT_FOUND", 404);
    }

    // Validate flow before publishing
    const nodes = flow.getNodes();
    const edges = flow.getEdges();

    if (!nodes.some(node => node.type === 'start')) {
      throw new AppError("ERR_FLOW_MISSING_START_NODE", 400);
    }

    if (!nodes.some(node => node.type === 'end')) {
      throw new AppError("ERR_FLOW_MISSING_END_NODE", 400);
    }

    if (nodes.length === 0) {
      throw new AppError("ERR_FLOW_EMPTY", 400);
    }

    const updatedFlow = await flowRepository.update({
      isPublished: true,
      publishedAt: new Date(),
      isActive: true,
    });

    // Emit socket event
    WebSocketService.emitToCompany(companyId, 'flow_published', {
      flow: updatedFlow[0],
      timestamp: new Date(),
    });

    logger.info("Flow published successfully", { flowId: id });

    return res.status(200).json(updatedFlow[0]);
  } catch (err) {
    logger.error("Error publishing flow:", err);
    throw new AppError("ERR_PUBLISH_FLOW", 500);
  }
};

export const unpublish = async (req: AuthenticatedRequest, res: Response): Promise<Response> => {
  try {
    const { id } = req.params;
    const { companyId } = req.user;

    const flowRepository = getRepository(Flow);
    const flow = await flowRepository.findOne({
      where: { id, companyId },
    });

    if (!flow) {
      throw new AppError("ERR_FLOW_NOT_FOUND", 404);
    }

    const updatedFlow = await flowRepository.update({
      isPublished: false,
      publishedAt: null,
    });

    // Emit socket event
    WebSocketService.emitToCompany(companyId, 'flow_unpublished', {
      flowId: id,
      timestamp: new Date(),
    });

    logger.info("Flow unpublished successfully", { flowId: id });

    return res.status(200).json(updatedFlow[0]);
  } catch (err) {
    logger.error("Error unpublishing flow:", err);
    throw new AppError("ERR_UNPUBLISH_FLOW", 500);
  }
};

export const test = async (req: AuthenticatedRequest, res: Response): Promise<Response> => {
  try {
    const { id } = req.params;
    const {
      testMessage = "Mensagem de teste",
      testContact = {
        number: "5511999998888",
        name: "Contato Teste"
      },
      variables = {}
    } = req.body;

    const { companyId } = req.user;

    const flowRepository = getRepository(Flow);
    const flow = await flowRepository.findOne({
      where: { id, companyId },
    });

    if (!flow) {
      throw new AppError("ERR_FLOW_NOT_FOUND", 404);
    }

    const flowEngine = new FlowEngine();

    const context = {
      ticketId: 0, // Test ticket ID
      companyId,
      contactId: 0, // Test contact ID
      variables: new Map(Object.entries(variables)),
      sessionId: uuidv4(),
      startTime: new Date(),
      executionId: uuidv4(),
      history: [],
    };

    // Create a test ticket in database
    const testTicket = {
      id: 0,
      contact: testContact,
      companyId,
    };

    const execution = await flowEngine.executeFlow(flow, context);

    // Emit socket event
    WebSocketService.emitToCompany(companyId, 'flow_test_started', {
      flowId: id,
      executionId: context.executionId,
      testMessage,
      timestamp: new Date(),
    });

    logger.info("Flow test started", {
      flowId: id,
      executionId: context.executionId,
      testMessage,
    });

    return res.status(200).json({
      message: "Test started successfully",
      executionId: context.executionId,
      flow: {
        id: flow.id,
        name: flow.name,
        nodes: flow.getNodes().length,
        edges: flow.getEdges().length,
      },
    });
  } catch (err) {
    logger.error("Error testing flow:", err);
    throw new AppError("ERR_TEST_FLOW", 500);
  }
};

export const duplicate = async (req: AuthenticatedRequest, res: Response): Promise<Response> => {
  try {
    const { id } = req.params;
    const { companyId, id: userId } = req.user;

    const flowRepository = getRepository(Flow);
    const originalFlow = await flowRepository.findOne({
      where: { id, companyId },
    });

    if (!originalFlow) {
      throw new AppError("ERR_FLOW_NOT_FOUND", 404);
    }

    const duplicatedFlow = flowRepository.create({
      id: uuidv4(),
      name: `${originalFlow.name} (Cópia)`,
      description: originalFlow.description,
      companyId,
      createdBy: userId,
      category: originalFlow.category,
      nodes: originalFlow.nodes,
      edges: originalFlow.edges,
      variables: originalFlow.variables,
      settings: originalFlow.settings,
      triggerType: originalFlow.triggerType,
      triggerConfig: originalFlow.triggerConfig,
      tags: originalFlow.tags,
      priority: originalFlow.priority + 1,
      timeoutMinutes: originalFlow.timeoutMinutes,
      errorHandling: originalFlow.errorHandling,
      analytics: originalFlow.analytics,
      isActive: false,
      isPublished: false,
      version: 1,
    });

    // Emit socket event
    WebSocketService.emitToCompany(companyId, 'flow_duplicated', {
      originalFlowId: id,
      newFlowId: duplicatedFlow.id,
      timestamp: new Date(),
    });

    logger.info("Flow duplicated successfully", {
      originalFlowId: id,
      newFlowId: duplicatedFlow.id,
    });

    return res.status(201).json(duplicatedFlow);
  } catch (err) {
    logger.error("Error duplicating flow:", err);
    throw new AppError("ERR_DUPLICATE_FLOW", 500);
  }
};

export const listExecutions = async (req: AuthenticatedRequest, res: Response): Promise<Response> => {
  try {
    const { id } = req.params;
    const { companyId } = req.user;
    const {
      page = 1,
      limit = 20,
      status = null,
      startDate = null,
      endDate = null,
    } = req.query;

    const executionRepository = getRepository(FlowExecution);

    const whereConditions: any = {
      flowId: id,
      companyId,
    };

    if (status) {
      whereConditions.status = status;
    }

    if (startDate) {
      whereConditions.createdAt = {
        ...whereConditions.createdAt,
        $gte: new Date(startDate as string),
      };
    }

    if (endDate) {
      whereConditions.createdAt = {
        ...whereConditions.createdAt,
        $lte: new Date(endDate as string),
      };
    }

    const [executions, count] = await executionRepository.findAndCount({
      where: whereConditions,
      order: { startTime: 'DESC' },
      take: Number(limit),
      skip: (Number(page) - 1) * Number(limit),
      relations: ["flow", "contact", "user"],
    });

    return res.status(200).json({
      executions,
      count,
      hasMore: (Number(page) * Number(limit)) < count,
    });
  } catch (err) {
    logger.error("Error listing flow executions:", err);
    throw new AppError("ERR_LIST_EXECUTIONS", 500);
  }
};

export const getExecution = async (req: AuthenticatedRequest, res: Response): Promise<Response> => {
  try {
    const { id, executionId } = req.params;
    const { companyId } = req.user;

    const executionRepository = getRepository(FlowExecution);
    const execution = await executionRepository.findOne({
      where: { flowId: id, executionId, companyId },
      relations: ["flow", "contact", "user"],
    });

    if (!execution) {
      throw new AppError("ERR_EXECUTION_NOT_FOUND", 404);
    }

    const parsedExecution = {
      ...execution,
      variables: execution.getVariables(),
      steps: execution.getSteps(),
      result: execution.getResult(),
      metrics: execution.getMetrics(),
      duration: execution.getDuration(),
      stepCount: execution.getStepCount(),
    };

    return res.status(200).json(parsedExecution);
  } catch (err) {
    logger.error("Error getting flow execution:", err);
    throw new AppError("ERR_GET_EXECUTION", 500);
  }
};

export const stopExecution = async (req: AuthenticatedRequest, res: Response): Promise<Response> => {
  try {
    const { id, executionId } = req.params;
    const { companyId } = req.user;

    const executionRepository = getRepository(FlowExecution);
    const execution = await executionRepository.findOne({
      where: { flowId: id, executionId, companyId },
    });

    if (!execution) {
      throw new AppError("ERR_EXECUTION_NOT_FOUND", 404);
    }

    if (execution.status !== 'running') {
      throw new AppError("ERR_EXECUTION_NOT_RUNNING", 400);
    }

    // Stop the flow execution
    const flowEngine = new FlowEngine();
    await flowEngine.stopExecution(executionId);

    // Update execution status
    await executionRepository.update({
      status: 'stopped',
      endTime: new Date(),
    });

    // Emit socket event
    WebSocketService.emitToCompany(companyId, 'flow_execution_stopped', {
      flowId: id,
      executionId,
      timestamp: new Date(),
    });

    logger.info("Flow execution stopped", {
      flowId: id,
      executionId,
    });

    return res.status(200).json({ message: "Execution stopped successfully" });
  } catch (err) {
    logger.error("Error stopping flow execution:", err);
    throw new AppError("ERR_STOP_EXECUTION", 500);
  }
};

export const getAnalytics = async (req: AuthenticatedRequest, res: Response): Promise<Response> => {
  try {
    const { id } = req.params;
    const { companyId } = req.user;
    const {
      startDate = null,
      endDate = null,
      groupBy = 'day',
    } = req.query;

    const executionRepository = getRepository(FlowExecution);

    const whereConditions: any = {
      flowId: id,
      companyId,
    };

    if (startDate) {
      whereConditions.startTime = {
        ...whereConditions.startTime,
        $gte: new Date(startDate as string),
      };
    }

    if (endDate) {
      whereConditions.startTime = {
        ...whereConditions.startTime,
        $lte: new Date(endDate as string),
      };
    }

    const executions = await executionRepository.find({
      where: whereConditions,
      order: { startTime: 'DESC' },
    });

    // Calculate analytics
    const analytics = {
      totalExecutions: executions.length,
      successfulExecutions: executions.filter(e => e.status === 'completed').length,
      failedExecutions: executions.filter(e => e.status === 'error').length,
      stoppedExecutions: executions.filter(e => e.status === 'stopped').length,
      averageDuration: executions.length > 0
        ? executions.reduce((sum, e) => sum + e.getDuration(), 0) / executions.length
        : 0,
      executionsByStatus: executions.reduce((acc, e) => {
        acc[e.status] = (acc[e.status] || 0) + 1;
        return acc;
      }, {}),
      executionsByDay: groupBy === 'day' ?
        executions.reduce((acc, e) => {
          const day = e.startTime.toISOString().split('T')[0];
          acc[day] = (acc[day] || 0) + 1;
          return acc;
        }, {})
        : {},
    };

    return res.status(200).json(analytics);
  } catch (err) {
    logger.error("Error getting flow analytics:", err);
    throw new AppError("ERR_GET_ANALYTICS", 500);
  }
};

export const export = async (req: AuthenticatedRequest, res: Response): Promise<Response> => {
  try {
    const { id } = req.params;
    const { companyId } = req.user;

    const flowRepository = getRepository(Flow);
    const flow = await flowRepository.findOne({
      where: { id, companyId },
    });

    if (!flow) {
      throw new AppError("ERR_FLOW_NOT_FOUND", 404);
    }

    const exportData = {
      flow: {
        name: flow.name,
        description: flow.description,
        category: flow.category,
        nodes: flow.getNodes(),
        edges: flow.getEdges(),
        variables: flow.getVariables(),
        settings: flow.getSettings(),
        triggerType: flow.triggerType,
        triggerConfig: flow.getTriggerConfig(),
        tags: flow.tags,
        priority: flow.priority,
        timeoutMinutes: flow.timeoutMinutes,
        errorHandling: flow.getErrorHandling(),
        analytics: flow.getAnalytics(),
      },
      exportedAt: new Date().toISOString(),
      exportedBy: req.user.email,
      version: flow.version,
    };

    res.setHeader('Content-Type', 'application/json');
    res.setHeader(
      'Content-Disposition',
      `attachment; filename="${flow.name.replace(/[^a-zA-Z0-9]/g, '_')}.json"`
    );

    return res.status(200).json(exportData);
  } catch (err) {
    logger.error("Error exporting flow:", err);
    throw new AppError("ERR_EXPORT_FLOW", 500);
  }
};

export const import = async (req: AuthenticatedRequest, res: Response): Promise<Response> => {
  try {
    const { flowData } = req.body;
    const { companyId, id: userId } = req.user;

    if (!flowData || !flowData.flow) {
      throw new AppError("ERR_INVALID_FLOW_DATA", 400);
    }

    const { flow: flowConfig } = flowData;

    const flowRepository = getRepository(Flow);

    const importedFlow = flowRepository.create({
      id: uuidv4(),
      name: flowConfig.name || 'Imported Flow',
      description: flowConfig.description || 'Imported from external source',
      companyId,
      createdBy: userId,
      category: flowConfig.category || 'custom',
      nodes: JSON.stringify(flowConfig.nodes || []),
      edges: JSON.stringify(flowConfig.edges || []),
      variables: JSON.stringify(flowConfig.variables || {}),
      settings: JSON.stringify(flowConfig.settings || {}),
      triggerType: flowConfig.triggerType || 'message',
      triggerConfig: JSON.stringify(flowConfig.triggerConfig || {}),
      tags: flowConfig.tags || [],
      priority: flowConfig.priority || 1,
      timeoutMinutes: flowConfig.timeoutMinutes,
      errorHandling: JSON.stringify(flowConfig.errorHandling || {}),
      analytics: JSON.stringify(flowConfig.analytics || {}),
      isActive: false,
      isPublished: false,
      version: 1,
    });

    logger.info("Flow imported successfully", {
      flowId: importedFlow.id,
      name: importedFlow.name,
    });

    return res.status(201).json(importedFlow);
  } catch (err) {
    logger.error("Error importing flow:", err);
    throw new AppError("ERR_IMPORT_FLOW", 500);
  }
};

export const getNodeTypes = async (req: AuthenticatedRequest, res: Response): Promise<Response> => {
  try {
    const nodeTypes = [
      {
        type: 'start',
        label: 'Início',
        description: 'Ponto inicial do fluxo',
        category: 'control',
        config: {},
      },
      {
        type: 'end',
        label: 'Fim',
        description: 'Ponto final do fluxo',
        category: 'control',
        config: {},
      },
      {
        type: 'sendMessage',
        label: 'Enviar Mensagem',
        description: 'Envia uma mensagem de texto',
        category: 'messaging',
        config: {
          message: { type: 'string', required: true },
          messageType: { type: 'string', enum: ['text'] },
        },
      },
      {
        type: 'sendMedia',
        label: 'Enviar Mídia',
        description: 'Envia imagem, vídeo ou documento',
        category: 'messaging',
        config: {
          mediaUrl: { type: 'string', required: true },
          mediaType: { type: 'string', enum: ['image', 'video', 'audio', 'document'] },
          caption: { type: 'string' },
        },
      },
      {
        type: 'condition',
        label: 'Condição',
        description: 'Caminho baseado em condições',
        category: 'logic',
        config: {
          conditions: { type: 'array', required: true },
        },
      },
      {
        type: 'menu',
        label: 'Menu Interativo',
        description: 'Apresenta opções ao usuário',
        category: 'interaction',
        config: {
          title: { type: 'string' },
          options: { type: 'array', required: true },
          waitForResponse: { type: 'boolean', default: true },
          timeout: { type: 'number', default: 30000 },
        },
      },
      {
        type: 'delay',
        label: 'Esperar',
        description: 'Pausa por um tempo definido',
        category: 'utility',
        config: {
          delay: { type: 'number', required: true },
          delayUnit: { type: 'string', enum: ['seconds', 'minutes', 'hours'] },
        },
      },
      {
        type: 'apiCall',
        label: 'Chamada API',
        description: 'Faz requisição HTTP',
        category: 'integration',
        config: {
          url: { type: 'string', required: true },
          method: { type: 'string', enum: ['GET', 'POST', 'PUT', 'DELETE'] },
          headers: { type: 'object' },
          body: { type: 'string' },
          timeout: { type: 'number', default: 10000 },
          errorHandling: { type: 'string', enum: ['continue', 'stop'] },
        },
      },
      {
        type: 'webhook',
        label: 'Webhook',
        description: 'Envia dados para webhook',
        category: 'integration',
        config: {
          url: { type: 'string', required: true },
          method: { type: 'string', default: 'POST' },
          headers: { type: 'object' },
          body: { type: 'string' },
          secret: { type: 'string' },
        },
      },
      {
        type: 'variable',
        label: 'Variável',
        description: 'Manipula variáveis',
        category: 'data',
        config: {
          operation: { type: 'string', enum: ['set', 'get', 'increment', 'decrement', 'delete'] },
          variableName: { type: 'string', required: true },
          value: { type: 'any' },
        },
      },
      {
        type: 'validation',
        label: 'Validação',
        description: 'Valida dados de entrada',
        category: 'logic',
        config: {
          validations: { type: 'array', required: true },
        },
      },
      {
        type: 'tag',
        label: 'Tag',
        description: 'Adiciona/remove tags',
        category: 'data',
        config: {
          operation: { type: 'string', enum: ['add', 'remove', 'list'] },
          tags: { type: 'array' },
        },
      },
      {
        type: 'queue',
        label: 'Fila',
        description: 'Transferir para fila',
        category: 'routing',
        config: {
          queueId: { type: 'number', required: true },
        },
      },
      {
        type: 'humanHandoff',
        label: 'Transferir Humano',
        description: 'Transferir para atendente',
        category: 'routing',
        config: {
          reason: { type: 'string' },
        },
      },
      {
        type: 'analytics',
        label: 'Analytics',
        description: 'Registra eventos',
        category: 'analytics',
        config: {
          event: { type: 'string', required: true },
          data: { type: 'object' },
        },
      },
    ];

    return res.status(200).json({
      nodeTypes,
      categories: [
        { value: 'control', label: 'Controle' },
        { value: 'messaging', label: 'Mensagem' },
        { value: 'logic', label: 'Lógica' },
        { value: 'interaction', label: 'Interação' },
        { value: 'utility', label: 'Utilidade' },
        { value: 'integration', label: 'Integração' },
        { value: 'data', label: 'Dados' },
        { value: 'routing', label: 'Roteamento' },
        { value: 'analytics', label: 'Analytics' },
      ],
    });
  } catch (err) {
    logger.error("Error getting node types:", err);
    throw new AppError("ERR_GET_NODE_TYPES", 500);
  }
};

export const getStats = async (req: AuthenticatedRequest, res: Response): Promise<Response> => {
  try {
    const { companyId } = req.user;

    const flowRepository = getRepository(Flow);
    const executionRepository = getRepository(FlowExecution);

    const [totalFlows, activeFlows, publishedFlows] = await Promise.all([
      flowRepository.count({ where: { companyId } }),
      flowRepository.count({ where: { companyId, isActive: true } }),
      flowRepository.count({ where: { companyId, isPublished: true } }),
    ]);

    const executionsByStatus = await executionRepository
      .createQueryBuilder('execution')
      .select('status')
      .addSelect('COUNT(*)', 'count')
      .where('companyId = :companyId', { companyId })
      .groupBy('status')
      .getRawMany();

    const stats = {
      totalFlows,
      activeFlows,
      publishedFlows,
      executionsByStatus: executionsByStatus.reduce((acc, row) => {
        acc[row.status] = parseInt(row.count);
        return acc;
      }, {}),
      totalExecutions: Object.values(executionsByStatus).reduce((sum, count) => sum + count, 0),
    };

    return res.status(200).json(stats);
  } catch (err) {
    logger.error("Error getting flow stats:", err);
    throw new AppError("ERR_GET_FLOW_STATS", 500);
  }
};

export default {
  index,
  show,
  store,
  update,
  remove,
  publish,
  unpublish,
  test,
  duplicate,
  listExecutions,
  getExecution,
  stopExecution,
  getAnalytics,
  export,
  import,
  getNodeTypes,
  getStats,
};