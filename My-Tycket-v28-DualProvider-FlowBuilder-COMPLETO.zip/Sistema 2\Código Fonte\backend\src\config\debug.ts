// Configurações de debug para o sistema
export const ENABLE_LID_DEBUG = process.env.ENABLE_LID_DEBUG === "true" || false;
